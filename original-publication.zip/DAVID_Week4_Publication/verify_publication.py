"""Verify every file listed in this publication's SHA-256 manifest, offline."""
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent


def verify():
    manifest = json.loads((ROOT / "MANIFEST_SHA256.json").read_text())
    failures = []
    for relative, expected in manifest["files"].items():
        path = PurePosixPath(relative)
        full = ROOT / relative
        if path.is_absolute() or ".." in path.parts or not full.resolve().is_relative_to(ROOT):
            failures.append({"file": relative, "reason": "unsafe path"})
        elif not full.is_file():
            failures.append({"file": relative, "reason": "missing file"})
        elif hashlib.sha256(full.read_bytes()).hexdigest() != expected:
            failures.append({"file": relative, "reason": "SHA-256 mismatch"})
    return {"status": "failed" if failures else "passed",
            "files_checked": len(manifest["files"]), "mismatches": failures,
            "scope": "Listed distribution files only; extra local environments and audit outputs are allowed.",
            "limit": "File consistency, not publisher, RPC or canonical-chain authentication."}


if __name__ == "__main__":
    result = verify()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "passed" else 1)
