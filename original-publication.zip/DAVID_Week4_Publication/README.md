# Rayls Checkpoint Verification: Complete Reproduction Guide

This package accompanies **How Can You Verify a Blockchain Checkpoint? Lessons from 175 Rayls Epoch Records**. It includes the raw observations, pinned sources, verification programs, article and four evidence figures.

The question is practical: **can a reader reconstruct what a certificate signs, verify its authorized quorum, follow committee changes, and connect the checkpoint to an execution header?**

Start with the saved-data audit below. No wallet, private key, tokens or paid transaction is needed. Dependency installation needs internet access; the fixed-study checks then work offline. A separate optional command performs public RPC queries.

## 1. What the study found

| Observation | Fixed result |
|---|---|
| Reported network | Rayls mainnet, chain ID 72957 |
| Original capture | 22 October 2026 |
| Second capture | 23 October 2026, same endpoint |
| Fixed range | Epochs 0 through 174: 175 records per capture |
| Digests and aggregate signatures | All 175 verified in each saved capture |
| Parent links | 174 per sequence |
| Committee handoffs | 174 checked; membership changed once |
| Membership change | Seven keys through epoch 171; eight from 172; one added, none removed |
| Original local controls | 13 expected outcomes: 12 rejections and one valid synthetic positive |
| Execution headers | Epochs 0, 173 and 174; blocks 1, 12,884,728 and 12,948,967 |
| Record comparison | All 175 record objects/digests identical |
| Certificate comparison | 163 identical; 12 different signer bitmaps and aggregate signatures |
| Additional second-library checks | Both variants for each changed epoch: 24 py_ecc checks |
| Initial committee | Observed from RPC; not independently authenticated out of band |

Source analysis is pinned to commit **6909618ba3d178884e613b329a99816ba546f62e**, associated with **mainnet-v1.4.1**. An endpoint version string aligns the source analysis; it is not remote attestation of its binary.

These are record/check counts, not 175 independent experiments or 24 new checkpoints. Both captures came from the same official endpoint. All continuity and signature results remain relative to the observed starting committee.

## 2. Download and find the correct directory

If reading on GitHub and only the publication ZIP is uploaded, download **DAVID_Week4_Checkpoint_Publication.zip** and extract it.

A GitHub repository-source ZIP and the publication ZIP are separate layers. Extracting the repository download can leave the publication ZIP inside it; extract that too.

Open a terminal in the extracted **DAVID_Week4_Publication** directory. This guide calls it the **publication root**. If files were uploaded directly to a repository, use the directory containing **verify_all.py**, **evidence/** and **images/**.

| Root path | Purpose |
|---|---|
| README.md | This complete guide |
| verify_all.py | Ten-step audit that preserves packaged observations |
| verify_publication.py | Standard-library check of outer-manifest hashes |
| ARTICLE_COPY.md | Clean English article text |
| ARTICLE.md | Article with image references and captions |
| ARTICLE.html | Standalone illustrated version with embedded images |
| images/ | Four full-resolution PNGs and editable SVGs |
| figure-data.json | Values used in the figures |
| figure-text-bounds.json | Recorded text positions and widths |
| evidence/original/ | Original data, programs and original 49-entry manifest |
| evidence/fresh-capture/ | Saved second capture and verification programs |
| evidence/review/ | Comparisons, byte vectors, additional checks and logs |
| MANIFEST_SHA256.json | Hashes of delivered files except the manifest itself |

A Windows example is **C:\Users\YOUR_NAME\Downloads\DAVID_Week4_Publication**. Substitute your real path. Run from an extracted folder, not a ZIP viewer.

## 3. Prepare the pinned Python environment

The recorded cryptographic runs used **Linux with Python 3.12**. Locked dependencies installed successfully there. Native Windows and macOS execution were not tested by this review.

### Linux

From the publication root:

~~~bash
python3.12 --version
python3.12 -m venv .venv
.venv/bin/python -m pip install -r evidence/original/requirements-lock.txt
~~~

Expected: Python reports 3.12.x, the environment is created, and pip finishes without installation errors.

### Windows PowerShell

From the publication root:

~~~powershell
py -3.12 --version
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\evidence\original\requirements-lock.txt
~~~

These commands call the interpreter directly. They do not require **Activate.ps1** or a PowerShell execution-policy change. If the **py** launcher is unavailable, use the full path to an installed Python 3.12 interpreter for the first two commands.

Use that same environment interpreter for later steps. Installing dependencies into one Python and running with another causes missing-module errors.

The lock includes **pyblst 0.3.15**, **py_ecc 8.0.0**, and dependencies for BLAKE3, Keccak, Base58 and Roaring bitmaps. Use the supplied lock instead of choosing unrelated latest versions.

Run without Python's **-O** or **-OO** options. Supplemental programs use assertions, and the complete launcher rejects optimized execution.

## 4. Run all ten saved-data checks

Linux:

~~~bash
.venv/bin/python verify_all.py --output audit-output/first-run
~~~

Windows PowerShell:

~~~powershell
.\.venv\Scripts\python.exe .\verify_all.py --output .\audit-output\first-run
~~~

The output directory must not already exist. For another run, select **audit-output/second-run**, or omit **--output** to create a timestamped directory.

| Step | Check | What it checks |
|---:|---|---|
| 1 | Publication integrity | Outer-manifest hashes |
| 2 | Review integrity | Reviewed-evidence manifest |
| 3 | Original integrity | Original 49 entries and nine source blob identities |
| 4 | Original checkpoints | Digests, signatures, quorum, links, handoffs, controls and py_ecc samples |
| 5 | Original headers | Three RLP/Keccak commitments and local mutations |
| 6 | Recaptured checkpoints | Full checkpoint checks on the saved second capture |
| 7 | Recaptured headers | Second-capture header commitments |
| 8 | Capture comparison | 175 unchanged records, 12 certificate variants, identical sampled block responses |
| 9 | Alternate certificates | Both variants for all 12 changed epochs using py_ecc |
| 10 | Encoding recipes | Four encoding/hash comparisons and exact intent samples |

Integrity is checked before regeneration. Steps 4–10 run against a separate **working-evidence/** copy inside your output directory. **The delivered evidence and result files remain unchanged.** A final outer-manifest check confirms that the distributed files still match their hashes.

This command makes no live RPC query, opens no wallet and submits no transaction. Pairing verification can take time. Progress is printed by step, with a separate log for each. Runtime depends on the machine.

## 5. Read the result and logs

Paths are relative to your chosen output directory:

| Output | Inspect |
|---|---|
| audit-summary.json | Overall status, Python version, exit codes, elapsed time and log paths |
| logs/01-publication-integrity.log | Outer integrity result |
| logs/03-original-integrity.log | Original manifest and nine source identities |
| logs/04-original-checkpoints.log | Record results and all 13 controls |
| logs/05-original-headers.log | Original header calculations |
| logs/08-capture-comparison.log | Certificate alternatives and unchanged records |
| logs/09-alternate-certificates-pyecc.log | 24 PASS lines plus the final report |
| logs/10-encoding-recipes.log | Recipe counts and exact signing-input samples |
| working-evidence/original/results/ | Regenerated original JSON and CSV |
| working-evidence/fresh-capture/results/ | Regenerated second-capture results |

Selected expected summary fields:

~~~json
{
  "status": "passed",
  "steps_completed": 10,
  "expected_steps": 10,
  "error": null
}
~~~

Every step should have exit code **0**, and **manifest_identity_preserved** should be **true**. The report also contains machine-dependent timings and exact interpreter paths.

The launcher stops at the first failed step, writes a failure report and exits nonzero. A partial run is not a complete pass. Read the failing step's log to distinguish an environment error from a verification mismatch.

## 6. Run individual checks manually

These diagnostic commands start in the publication root. They are unnecessary after a complete successful audit.

**Direct checkpoint/header commands regenerate adjacent result files.** Run integrity first; use a separate extraction for manual experiments or the preserving full launcher above.

### Linux

~~~bash
.venv/bin/python verify_publication.py
.venv/bin/python evidence/verify_review_package.py
.venv/bin/python evidence/original/verify_package.py
.venv/bin/python evidence/original/verify_checkpoints.py
.venv/bin/python evidence/original/verify_headers.py
.venv/bin/python evidence/fresh-capture/verify_checkpoints.py
.venv/bin/python evidence/fresh-capture/verify_headers.py
.venv/bin/python evidence/review/compare_captures.py
.venv/bin/python evidence/review/check_alternate_certificates.py
.venv/bin/python evidence/review/check_recipes.py
~~~

### Windows PowerShell

~~~powershell
.\.venv\Scripts\python.exe .\verify_publication.py
.\.venv\Scripts\python.exe .\evidence\verify_review_package.py
.\.venv\Scripts\python.exe .\evidence\original\verify_package.py
.\.venv\Scripts\python.exe .\evidence\original\verify_checkpoints.py
.\.venv\Scripts\python.exe .\evidence\original\verify_headers.py
.\.venv\Scripts\python.exe .\evidence\fresh-capture\verify_checkpoints.py
.\.venv\Scripts\python.exe .\evidence\fresh-capture\verify_headers.py
.\.venv\Scripts\python.exe .\evidence\review\compare_captures.py
.\.venv\Scripts\python.exe .\evidence\review\check_alternate_certificates.py
.\.venv\Scripts\python.exe .\evidence\review\check_recipes.py
~~~

The checkpoint verifier offers **--skip-second-library** for diagnosis. That omits its three py_ecc samples and is not equivalent to the complete workflow.

## 7. Map article claims to files

All paths start at the publication root. Short paths beginning with **original/** are inside **evidence/**.

| Claim | Evidence | Reproduction |
|---|---|---|
| 175 original records | evidence/original/epochs/batch-*.json | Original checkpoint verifier |
| Digests and signatures pass | Raw batches; original/results/checkpoints.csv and summary.json | Serialization, hashing and BLS checks |
| 174 links and handoffs | Same batches and summary | verify_chain |
| One membership change | Summary committee_changes and adjacent raw epochs | Membership-set and handoff checks |
| 13 controls | Summary offline_boundary_controls | negative_tests |
| Three header commitments | Each capture's checkpoint-blocks.json and results/header-checks.json | Its header verifier |
| 12 certificate alternatives | Both captures; evidence/review/recapture-comparison.json | compare_captures.py |
| 24 additional checks | evidence/review/alternate-certificates-pyecc.json | check_alternate_certificates.py |
| Encoding/hash results | evidence/review/review-recipe-checks.json | check_recipes.py |
| 36-byte intents | evidence/review/review-byte-vectors.json | Recipe program and original domain controls |
| Nine source identities | evidence/original/source-index.json, source/ and evidence/review/fresh-source-observations.json | Offline blob identities |
| Original anchor | Both OBSERVED_ANCHOR.json files | Equality retained, not independent authentication |

Recomputed files from the full launcher are in its working copy. Saved reference outputs and old logs are not substitutes for actually running the programs.

## 8. Interpret the cryptographic checks

### Exact bytes and hash selection

The reviewed RPC guide describes Keccak and a u64 epoch field. The pinned implementation uses **Epoch = u32**, canonical BCS and BLAKE3 for this record digest.

| Recipe compared with the original 175 record hashes | Matches |
|---|---:|
| u32 BCS + BLAKE3 | 175 |
| u32 BCS + Keccak | 0 |
| u64 BCS + BLAKE3 | 0 |
| u64 BCS + Keccak | 0 |

These offline recipe comparisons are separate from the thirteen original controls and specific to the inspected release/record type.

The 36-byte signed input begins with **01 00 01** for scope/version/application, then hexadecimal **20** for a 32-byte BCS vector, then the digest. It is not the bare digest. Full record BCS and intent vectors are saved for epochs 0, 173 and 174.

### Quorum and authority

The certificate threshold is **floor(2*n/3)+1**: five of seven keys, six of eight. This is not a statement about every other Axyl voting-power rule.

A valid pairing equation does not establish authorization on its own. The synthetic one-key positive control has a valid self-signature, but the preceding committee's authorization check rejects its replacement committee. This tests the offline verifier; the synthetic record was not submitted to Rayls.

### Alternative certificates

Changed epochs: **136, 138, 141, 147, 151, 152, 159, 161, 163, 164, 168 and 173**.

| Epoch | Committee keys | Capture A signers | Capture B signers | Required |
|---:|---:|---:|---:|---:|
| 136 | 7 | 7 | 5 | 5 |
| 173 | 8 | 6 | 7 | 6 |

A is 22 October; B is 23 October. Both variants authenticate the same respective record under the same expected committee. Exact signer indices and signatures are in the comparison JSON. The operational cause was not established. Twenty-four checks cover twelve commitments, not twenty-four new checkpoints.

### Execution headers

| Epoch | Execution block |
|---:|---:|
| 0 | 1 |
| 173 | 12,884,728 |
| 174 | 12,948,967 |

Each reconstructed RLP header's Keccak hash matches its RPC hash and signed execution-block reference. A local **gasUsed** change breaks the match. Block 1 is not labelled as genesis. Header verification does not replay transactions or establish every execution-state transition.

## 9. Fetch new public observations

This is optional, needs internet access and is not run by **verify_all.py**.

Linux:

~~~bash
.venv/bin/python evidence/original/fetch_again.py --output audit-output/new-rpc-capture
~~~

Windows PowerShell:

~~~powershell
.\.venv\Scripts\python.exe .\evidence\original\fetch_again.py --output .\audit-output\new-rpc-capture
~~~

Use a new directory; the fetcher refuses to overwrite an existing one. It checks reported chain ID 72957 and saves metadata, requests, responses, UTC times, the fixed epoch range and sampled blocks.

Read-only methods used: **eth_chainId**, **web3_clientVersion**, **rayls_nodeStatus**, **rayls_epochRecord** and **eth_getBlockByNumber**. There is no signing or transaction-submission method.

A new capture is raw evidence, not automatically verified evidence. Later dates can return other certificate variants. Do not expect exactly twelve differences on every later date or treat the fixed comparison report as a new live test. Preserve the original captures and anchor and analyze new observations separately.

An RPC failure or unavailable response is not a zero value or proof of a missing record. Saved-data verification still works without a live endpoint.

## 10. Check file identity and pinned sources

There are three integrity layers:

1. The outer manifest covers article, figures, programs, documentation and evidence.
2. The reviewed-evidence manifest covers its distribution.
3. The original 49-entry manifest remains with the original captured files unchanged.

The outer checker verifies listed files. Extra local directories such as **.venv/** and **audit-output/** are allowed; a pass does not mean every file on the computer was audited.

The original integrity program calculates recorded source Git-blob identities offline. It does not contact GitHub. **fresh-source-observations.json** records the separate source comparison performed during review. Rerunning a manifest check is not a fresh upstream retrieval.

Primary sources at the pinned commit include [EpochRecord](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/primary/epoch.rs), [committee types](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/committee.rs), [hash selection](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/mod.rs), [intent](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/intent.rs) and [RPC guide](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/doc/crates/execution/rpc.md). The source index and upstream notices remain in **evidence/original/**.

Hashes establish consistency, not independent authentication of the RPC, publisher, starting committee or canonical network identity.

## 11. Troubleshooting

| Symptom | Action |
|---|---|
| Cannot open script or find evidence/ | Fully extract the publication ZIP and use the directory containing verify_all.py |
| py or python3.12 not found | Confirm Python 3.12 is installed; use its actual interpreter path |
| PowerShell blocks activation | Call .\.venv\Scripts\python.exe directly; activation is unnecessary |
| ModuleNotFoundError | Install the lock with the same environment interpreter used to execute |
| No matching distribution or native build failure | The platform lacks a compatible wheel/toolchain; recorded runs used Linux/Python 3.12; native Windows/macOS were not tested |
| Output directory exists | Use another name or omit --output |
| Hash mismatch | Inspect the named file; use a clean extraction if edited or regenerated; do not remove the check |
| BLS step takes time | Inspect its log and wait for actual completion or failure |
| AssertionError or ValueError | Record the failed step and log; investigate the mismatch |
| Optional RPC failure | Saved verification remains available; unavailable data is not zero |
| New certificate bytes differ | Compare commitments and validate signer sets; differing bytes alone do not establish conflicting checkpoints |

A reproducibility report should include OS, Python version, exact command, failed step and its log. Remove private local-path details if necessary. No credentials are needed.

## 12. Article, images and GitHub publishing

| Image | Dimensions | Position |
|---|---|---|
| 01-checkpoint-banner.png | 3200 x 1280, 5:2 | Cover |
| 02-exact-signed-bytes.png | 3200 x 1800, 16:9 | After Reconstructing the exact signed record |
| 03-valid-certificate-variants.png | 3200 x 1800, 16:9 | After A repeat capture changed certificates, not records |
| 04-authority-and-header-commitments.png | 3200 x 1800, 16:9 | After Connecting a signed record to an execution block |

**ARTICLE.html** already contains the figures. Captions map A/B to dates and identify shortened hashes; full values remain in the evidence. The supplied Rayls mark is unchanged, with its black background. SVGs use DejaVu Sans and DejaVu Sans Mono.

Suggested repository name: **david-rayls-checkpoint-study**. Upload this file as the repository's root **README.md**, alongside the publication ZIP, so visitors can read instructions before downloading. Preserve directory structure if uploading extracted files.

Once public, add the real repository/release permalink to the article. This update did not create or modify a GitHub repository and does not invent a public evidence URL. A commit/release permalink identifies the exact version inspected.

## 13. Scope and limitations

All results remain relative to the original observed epoch-0 committee. An independently authenticated genesis committee/checkpoint remains unresolved. Re-querying the same endpoint does not remove that assumption.

pyblst and Axyl share blst: the Python program is a separate harness, not an independent cryptographic implementation. py_ecc supplies the second implementation checks.

This is not a production light client, transaction execution replay, live bridge settlement test, performance benchmark, binary attestation or identification of eight independent validator organizations.

The controls exercise the offline verifier; synthetic inputs were not sent to mainnet. The documentation discrepancy is release-specific and captured records matched the implementation. Alternative valid certificates for unchanged records do not by themselves establish a fork or its operational cause.

Successful reproduction supports these observations. It does not guarantee a content-quest score.

