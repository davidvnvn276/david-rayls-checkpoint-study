"""Recapture the study's fixed range with read-only JSON-RPC methods.

No wallet, private key, signing or transaction-submission method is present.
Existing output directories are never overwritten.
"""
import argparse
import datetime
import json
from pathlib import Path
import time
import urllib.request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--endpoint", default="https://mainnet-rpc.rayls.com/")
    args = parser.parse_args()
    if not args.endpoint.startswith("https://"):
        raise SystemExit("Use an HTTPS public read endpoint.")
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=False)
    (out / "epochs").mkdir()

    def request(name, batch):
        record = {"endpoint": args.endpoint,
                  "captured_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "request": batch}
        req = urllib.request.Request(args.endpoint, data=json.dumps(batch).encode(),
                                     headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0",
                                              "Origin": "https://dapp.rayls.com"})
        with urllib.request.urlopen(req, timeout=45) as response:
            record["http_status"] = response.status
            record["response"] = json.load(response)
        (out / name).write_text(json.dumps(record, indent=2) + "\n")
        return record["response"]

    metadata = request("endpoint-metadata.json", [
        {"jsonrpc": "2.0", "id": i, "method": m, "params": []}
        for i, m in enumerate(["eth_chainId", "web3_clientVersion", "rayls_nodeStatus"])
    ])
    chain = next(r for r in metadata if r["id"] == 0)
    if chain.get("result") != hex(72957):
        raise SystemExit("Endpoint did not return the expected chain ID 72957; capture stopped.")
    # Chain ID alone is not an authentication of the starting validator keys.
    for start in range(0, 175, 10):
        batch = [{"jsonrpc": "2.0", "id": epoch, "method": "rayls_epochRecord", "params": [epoch]}
                 for epoch in range(start, min(start + 10, 175))]
        replies = request(f"epochs/batch-{start:03d}.json", batch)
        if not isinstance(replies, list) or len(replies) != len(batch) or any("result" not in r for r in replies):
            raise SystemExit(f"Incomplete epoch batch at {start}; inspect the saved response.")
        print(f"Saved epochs {start} through {min(start + 9, 174)}", flush=True)
        time.sleep(0.25)
    request("checkpoint-blocks.json", [
        {"jsonrpc": "2.0", "id": i, "method": "eth_getBlockByNumber", "params": [hex(n), False]}
        for i, n in enumerate([1, 12884728, 12948967])
    ])
    print("Capture complete. The original anchor has not been replaced or newly authenticated.")


if __name__ == "__main__":
    main()
