"""Check package file hashes and recorded upstream Git blob hashes; no dependencies or network."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / "MANIFEST_SHA256.json").read_text())
    failures = []
    for relative, digest in manifest["files"].items():
        path = ROOT / relative
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            failures.append(relative)
    index = json.loads((ROOT / "source-index.json").read_text())
    source_matches = 0
    for entry in index["files"]:
        data = (ROOT / entry["file"]).read_bytes()
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()
        if git_blob != entry["git_blob_sha"]:
            failures.append("source blob: " + entry["file"])
        else:
            source_matches += 1
    print(json.dumps({"manifest_files": len(manifest["files"]), "manifest_or_source_mismatches": failures,
                      "upstream_source_blob_matches": source_matches,
                      "limit": "Integrity relative to the packaged manifest; not publisher authentication or canonical chain authentication."}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
