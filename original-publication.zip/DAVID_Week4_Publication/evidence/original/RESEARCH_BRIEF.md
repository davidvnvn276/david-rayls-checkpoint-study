# Week 4 research decision for DAVID

Research capture: 22 October 2026, UTC. This is a topic-selection and feasibility report, not a published article or a promised moderator score.

## Recommended question and title

**How Can You Verify a Blockchain Checkpoint? Lessons from 175 Rayls Epoch Records**

The question is what a signed checkpoint proves, how a reader can check it, and where an initial trust assumption remains. Rayls is the concrete mainnet case study. Keep the article on this mechanism rather than expanding into tokenomics, TPS, bridging or a full consensus review.

The answer to place early in the article: reconstruct the exact record bytes, check its digest, verify a sufficient set of validator signatures, authenticate the committee through the preceding checkpoint, and compare the signed execution-block hash with the block header. A trusted starting committee/checkpoint is still necessary. Valid signatures alone do not establish canonical chain identity or replace execution replay.

## Why this is the leading choice

This direction has already passed a substantive feasibility check. It does not depend on a future fee conversion, a newly launched vault, a mainnet payment, a wallet, a video, an unavailable historical account-state query, or a local bridge with mocked transport.

It also directly addresses a weakness in the earlier fee study. Those archived RPC balance observations could be recalculated but were not independently authenticated by their own protocol signatures. The epoch records here carry aggregate signatures that can be checked offline, relative to an explicitly chosen initial committee. Preserving a JSON response is not the same thing as verifying such a signature; the package does both.

This does not mean read-only research automatically earns 9 RP. Its value must come from the independently reproduced evidence, source reconciliation, clear trust boundary and useful explanation. Counting more files, tests or images does not itself raise the score.

## Completed work

| Check | Observed result | Scope |
| --- | --- | --- |
| Captured epoch records | 175 consecutive records, epochs 0 through 174 | Fixed historical range retrieved on 22 October; not a claim about all future epochs |
| Record digests | 175/175 match BLAKE3 over reconstructed BCS bytes | Independent serializer follows the pinned source |
| Aggregate BLS verification | 175/175 pass with sufficient signer counts | Python verifier uses pyblst, which wraps the same cryptographic library family as Axyl |
| Parent links | 174/174 match | Each record names the preceding record hash |
| Committee continuity | 174/174 match | Each new committee matches the preceding record's next_committee |
| Second cryptographic implementation | Epochs 0, 173 and 174 pass using py_ecc | Three cross-checks, not 175 second-library checks |
| Execution header commitments | Three header hashes are reconstructed and match the signed checkpoint hash | Blocks 1, 12,884,728 and 12,948,967; not full-chain execution replay |
| Local boundary/control cases | 13 expected outcomes pass | Includes one intentionally valid synthetic self-signature control; not 13 mainnet attacks |
| Local header corruption controls | A gasUsed change breaks the header commitment in each of three samples | Applied to local copies only |
| Pinned source copies | Nine files match their recorded Git blob hashes | Release mainnet-v1.4.1, commit 6909618ba3d178884e613b329a99816ba546f62e |

The RPC advertised client version `1.4.1 (6909618ba3d178884e613b329a99816ba546f62e)`. The public release tag resolves to that commit. This is a version alignment check; it is not remote binary attestation or proof that every validator runs that build.

## Three useful findings

### 1. A committee change can be followed through signed records

Epochs 0 through 171 contain seven committee keys. Epochs 172 through 174 contain eight. The transition adds one key and removes none. The preceding record's next committee matches the succeeding record's committee.

For the specific epoch-certificate verification rule in the pinned source, the threshold is `floor(2*n/3)+1`: five signatures for seven keys, six for eight. Do not generalize this unweighted epoch-certificate rule to every weighted voting rule elsewhere in the DAG protocol.

Do not translate eight keys into eight independent organizations, ownership groups, physical machines or cloud providers. Those identities and correlations were not established. Do not call the added key a newly independent operator without additional evidence.

This finding is useful supporting evidence about authenticated committee continuity. It should not become an unrelated decentralization-ranking article.

### 2. The record hash requires source reconciliation

The pinned release's `doc/crates/execution/rpc.md` describes an EpochRecord digest using Keccak and lists its epoch field as u64. The implementation uses `DefaultHashFunction = blake3::Hasher` and `Epoch = u32`, with BCS serialization. The B256 values and public keys also have BCS byte-vector length prefixes.

Using those implementation details reproduces all 175 captured hashes. Keccak on the same reconstructed record bytes reproduces none. A verifier following the prose hash description would therefore not reproduce this sample correctly.

Present this as a specific documentation/implementation mismatch for a pinned release. It is not evidence that a signature was forged, settlement was invalid, or the network's cryptography failed. The verified results show that these captured records are consistent with the implementation.

### 3. A mathematically valid signature is insufficient without authorized keys

One offline control creates a synthetic one-key committee and signs a locally modified record with a public test scalar. Its signature mathematics and one-of-one threshold pass. It fails when the verifier requires the actual preceding record's next committee.

This tests the author's verifier and explains a general trust boundary. It does **not** show that a Rayls node accepted a counterfeit checkpoint. No synthetic record, malformed request, transaction or attack was submitted to mainnet.

The real records then show both layers: valid signatures and a continuous committee history, relative to the explicit observed starting anchor.

## The most important remaining limit

The initial epoch-0 record and committee were observed from the same public RPC. This study has **not** independently authenticated an out-of-band genesis/initial-committee anchor. `OBSERVED_ANCHOR.json` makes that input and its limitation explicit.

There are two defensible publication paths:

1. Obtain an independently authenticated initial committee or checkpoint, preserve its provenance, and rerun the chain verification against it.
2. Keep the question explicitly about what checkpoint verification establishes, describe the initial anchor as observed, and make that unresolved identity assumption part of the answer.

Do not publish the title or claim "trustless mainnet finality proved" on the present evidence. Do not imply that chain ID, an RPC version string or a second query to the same endpoint authenticates the initial committee.

The checkpoint signatures also do not establish TPS, latency, censorship resistance, a production deployment by a named bank, external bridge settlement, or correctness of all executed state transitions. The three header checks bind header contents to signed hashes, not every transaction receipt or state update to an independently replayed execution.

## Article design

Use about 1,000 to 1,400 words as a working range, shortening wherever a paragraph repeats an already stated boundary. The evidence package carries raw detail; the article should carry the explanation.

1. Open with the question and the answer, including the starting-anchor condition.
2. State the 175-record result and fixed range. Explain what a checkpoint commits to in ordinary language.
3. Walk through one record from bytes to hash, signature quorum, previous committee and execution header. Link the exact files for readers who want to reproduce it.
4. Use the synthetic committee control to show why "valid signature" and "authorized signer" are separate checks. Label it prominently as synthetic and offline.
5. Explain the BLAKE3/prose mismatch as an integration lesson. Include the actual committee transition as supporting evidence, not a second thesis.
6. End with a compact statement of established results, the initial-anchor limit, and the reproducibility/source links. State each major limitation once where it matters; do not repeat it in every section.

Suggested opening, to refine after final review:

> A signed checkpoint is useful only if you check who was allowed to sign it. I retrieved 175 consecutive Rayls mainnet epoch records and independently checked their hashes, signature quorums and committee links. All passed the checks against an explicitly recorded starting anchor. That last condition matters: the signatures authenticate the chain relative to the starting keys; they do not independently tell you which starting keys to trust.

This is an accurate opening for the present evidence. It does not describe work the user personally ran unless the user also reruns the package. Attribution can use "This investigation" instead of "I" if needed.

## Visual plan

- Evidence figure: record bytes -> record digest -> signature quorum, with a separate preceding-committee requirement. Put the starting-anchor assumption visibly outside the verified chain.
- Data figure: committee keys 7 -> 8 at epoch 172, with the epoch-certificate thresholds 5 -> 6. Label keys rather than operators.
- Control figure: altered record / retained old signature = rejected; locally self-signed substitute / wrong authorized committee = rejected. Label every synthetic row.

Use exact generated charts or code-drawn diagrams. A headline cover is not evidence. Use untouched official brand assets if a logo is included. No fabricated terminal screenshots or generated numerical text.

## Moderator-risk review

The principal remaining risks are the unauthenticated initial anchor, the absence of full execution replay, the possibility that a reviewer considers the verification primarily a reproduction of an existing protocol mechanism, and technical density that hides the reader benefit.

A strong submission should foreground the concrete integration finding and the authorized-committee distinction, while preserving all limits. A second timestamp alone is not a substitute for those contributions. More tests of equivalent malformed inputs would add little.

This is a substantially developed candidate for a 9-RP submission. The moderator's score remains discretionary. The package is a research foundation, not a guarantee of 9 or 10 RP and not a completed review of final article text or images.

## Primary sources

- [Axyl technical specification](https://docs.rayls.com/docs/about-the-axyl-consensus-algorithm): documented epoch model and checkpoint purpose.
- [Public Chain developer reference](https://docs.rayls.com/docs/public-chain-reference): official endpoint and chain ID.
- [Pinned EpochRecord implementation](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/primary/epoch.rs): record fields, digest, quorum and signature checks.
- [Pinned hash selection](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/mod.rs): BLAKE3 alias.
- [Pinned RPC prose](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/doc/crates/execution/rpc.md): the exact description reconciled with the implementation.
- [Pinned codec](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/codec.rs): BCS encoding.
- [Pinned signature implementation](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/bls_signature.rs) and [intent](https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/intent.rs).
- [pyblst](https://github.com/OpShin/pyblst) and [py_ecc](https://github.com/ethereum/py_ecc): primary repositories for the two verification backends.

The raw observations and calculated results are in this package. Public RPC observations are not presented as claims extracted from these documentation pages.
