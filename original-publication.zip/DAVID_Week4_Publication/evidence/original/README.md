# DAVID Week 4: Rayls signed checkpoint research

Start with [RESEARCH_BRIEF.md](RESEARCH_BRIEF.md) for the proposed article, completed findings, evidence boundaries and remaining work. This package is a research foundation. It is not a published article, a production light client, a security audit, a transaction-finality oracle or a guaranteed quest score.

## What was actually run

On 22 October 2026, the public RPC at `https://mainnet-rpc.rayls.com/` returned chain ID 72957 and advertised client version `1.4.1 (6909618ba3d178884e613b329a99816ba546f62e)`.

The package preserves 175 epoch records, numbered 0 through 174, in 18 JSON-RPC batch responses. A separate Python verifier reconstructs their BCS bytes, recomputes BLAKE3 digests, checks BLS signatures and quorum, and verifies the complete sequence of parent hashes and next-committee links. Three signatures are cross-checked using py_ecc. Three execution header hashes are also independently reconstructed.

No wallet or paid transaction was used. The scripts have no transaction-signing or transaction-submission routine. Negative controls modify local data only.

## The initial trust assumption

`OBSERVED_ANCHOR.json` records the starting epoch-0 hash and committee **observed from the same public RPC**. No independent out-of-band authentication of those starting keys is claimed. The later certificate sequence is verified relative to that explicit input. A valid signature over a self-declared committee is not enough to authenticate a network.

The tests do not replay the EVM, validate every transaction receipt, benchmark finality latency, run an Axyl validator, measure stake-weighted decentralization, or prove a named bank uses any configuration. A BLS key count is not an independent-operator count.

## Folder guide

| Path | Purpose |
| --- | --- |
| `RESEARCH_BRIEF.md` | Topic decision, findings, article outline and publication risks |
| `epochs/batch-*.json` | Requests, endpoint, UTC capture time and unmodified parsed RPC responses |
| `chain-id.json`, `client-version.json`, `node-status.json` | Dated endpoint observations; node status describes that endpoint's node |
| `genesis-observed.json` | Genesis returned by the same RPC; not an independent root of trust |
| `OBSERVED_ANCHOR.json` | Explicit starting hash, keys and trust limitation |
| `checkpoint-blocks.json` | Three captured EVM checkpoint blocks |
| `verify_checkpoints.py` | Offline record, quorum, signature, chain and boundary checks |
| `verify_headers.py` | Offline RLP/header-hash reconstruction for the three samples |
| `results/summary.json` | Calculated verification results and local controls |
| `results/checkpoints.csv` | One row per captured epoch |
| `results/header-checks.json` | Header commitment results |
| `source/` | Nine pinned upstream files, plus upstream license and attribution |
| `source-index.json` | Pinned URLs and Git blob hashes for the nine source files |
| `fetch_again.py` | Optional, read-only recapture to a separate directory |
| `MANIFEST_SHA256.json` | File hashes for the delivered package, excluding the manifest itself |
| `verify_package.py` | Standard-library file-integrity and source-blob checks |

## Reproduce the saved checks, step by step

The recorded run used Linux and Python 3.12. The full Windows/macOS environment has not been tested. You do not need WSL, Docker, an RPC account or a private key to read the files. Installing the Python dependencies requires internet access; the verification commands then work with networking disconnected.

### 1. Extract the ZIP

Download the ZIP and use your operating system's Extract function. Open the extracted folder. The top-level folder is `DAVID_Week4_Checkpoint_Research` and contains this README. Keep all subfolders in place.

### 2. Open a terminal inside that folder

On Windows, right-click an empty area in the extracted folder and select Open in Terminal. On Linux/macOS, open a terminal and use `cd` with the full path to that folder.

Confirm Python is installed:

```bash
python --version
```

If your operating system uses `python3`, substitute `python3` for `python` below. Python 3.12 is recommended because it matches the recorded run.

### 3. Check the package before installing dependencies

```bash
python verify_package.py
```

This command only uses Python's standard library. It should report zero manifest mismatches and nine matching upstream source blob hashes. File hashes detect changes relative to this package manifest. They do not authenticate the publisher or prove network identity.

If you edit any packaged file, its hash will change. Preserve an untouched extracted copy if you want to run this integrity check again.

### 4. Create a dedicated Python environment

```bash
python -m venv .venv
```

Activate it on Linux/macOS:

```bash
source .venv/bin/activate
```

Activate it in Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell policy blocks activation, call the environment's Python directly instead of changing your machine's security policy. For example, use `.\.venv\Scripts\python.exe` wherever the following commands use `python`.

### 5. Install the pinned direct dependencies

```bash
python -m pip install -r requirements.txt
```

`requirements-lock.txt` records all package versions installed during the Linux research run. To request that same complete version set, use it instead of `requirements.txt`. Availability of wheels can depend on operating system, CPU and Python version. An installation failure is not a failed blockchain verification.

### 6. Run the checkpoint verification

```bash
python verify_checkpoints.py
```

Expected principal results:

- `records_verified`: 175
- `first_epoch`: 0, `last_epoch`: 174
- `parent_links_verified`: 174
- `committee_transitions_checked`: 174
- `blake3_hash_matches`: 175
- `keccak_hash_matches_for_same_BCS_bytes`: 0
- three successful `second_library_checks`
- `total_controls`: 13, each with `passed: true`

The count of 13 includes an intentionally accepted **synthetic** self-signature control. Its corresponding authenticated-committee check rejects the substitute. This does not show that Rayls accepted it.

This command rewrites `results/summary.json` and `results/checkpoints.csv` with the independently calculated results. It makes no network requests. On slower hardware, the three py_ecc checks take longer than the pyblst checks. To skip the second implementation, use `python verify_checkpoints.py --skip-second-library`; the resulting report will correctly list no second-library checks.

### 7. Verify the three EVM headers

```bash
python verify_headers.py
```

Expected: three results, for epochs 0, 173 and 174. Each reconstructed hash must equal both the RPC block hash and its signed checkpoint hash. A local `gasUsed` change must break each commitment. The command writes `results/header-checks.json` and does not use the network.

### 8. Read the outputs

Open `results/summary.json` in a text editor. Open `results/checkpoints.csv` in a text editor or spreadsheet program. The CSV contains exact epoch, signer count, committee size, threshold, checkpoint number and hashes. It is the simplest way to inspect the change from seven to eight committee keys at epoch 172.

Read `RESEARCH_BRIEF.md` before interpreting those numbers. In particular, eight keys do not establish eight independent organizations, and the count-based rule here is the epoch-certificate rule, not a universal statement about every consensus voting path.

## Optional: fetch the same public range again

This step requires internet access and uses the official public RPC. It performs only read methods. It saves a **new** directory and refuses to overwrite an existing one:

```bash
python fetch_again.py --output fresh-capture
```

It retrieves the same fixed range, epochs 0 through 174, and the three checkpoint blocks. It does not silently change the study to whatever epoch happens to be latest. Preserve the original capture as historical evidence.

A fresh capture does not automatically replace or authenticate the observed starting anchor. To run the offline verifier on a fresh capture, copy the scripts, requirements, and original `OBSERVED_ANCHOR.json` into that new directory, then run `verify_checkpoints.py` and `verify_headers.py` there. Keeping the old anchor makes a changed root fail instead of silently adopting it. Authenticate a different anchor independently before intentionally changing it.

RPC availability, routing or behavior may change. A failed recapture is not evidence that a historical certificate was invalid. The saved certificate checks remain independently executable against their recorded starting anchor.

## Source and scope details

The protocol files are pinned to commit `6909618ba3d178884e613b329a99816ba546f62e`, the target of the public `mainnet-v1.4.1` release tag. The RPC version string advertises that same commit. This is not binary attestation of the remote node.

The verifier is an independently written serializer and validation harness. Its fast backend uses pyblst, wrapping blst, which Axyl also uses. The three py_ecc checks provide a separate cryptographic implementation cross-check for those three samples. This distinction should remain visible in any article.

The implementation derives record hashes with BLAKE3 over BCS encoding. Ethereum execution block headers, separately, use Keccak over RLP. Do not swap those two layers when describing the finding.

Upstream source copies retain their license and attribution. See `source/UPSTREAM_LICENSE` and `source/UPSTREAM_NOTICE`. Package scripts are research examples and have not undergone a production security review.
