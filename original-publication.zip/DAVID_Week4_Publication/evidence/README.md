# Rayls checkpoint study: reviewed evidence supplement

This supplement preserves the supplied DAVID Week 4 checkpoint research and adds an independently executed review, a second capture of the same epoch range, exact byte vectors, comparison programs and an evidence-focused visual plan. All material is in English. Final artwork and a published article are not included.

## 1. Read the scope before interpreting a PASS

The original capture was made on 22 October 2026; the review recaptured epochs 0 through 174 on 23 October. Both came from the same official Rayls mainnet RPC. The original observed epoch-0 anchor is retained unchanged in both datasets. Neither the repeat query nor these file hashes independently authenticate that starting committee.

The review reproduced 175 record hashes and aggregate signatures, 174 parent links, 174 committee handoffs, 13 local controls and three execution-header commitments. All 175 record objects/digests were identical in the recapture. Twelve certificate objects changed their signer bitmap and aggregate signature, but both variants remained valid for the same record and committee. An additional 24 py_ecc checks covered the two variants for each of those 12 records.

These are saved-data cryptographic checks. They do not replay transaction execution, attest a running node binary, run a live bridge, or establish which organization owns each key. The source/version comparison is pinned to commit 6909618ba3d178884e613b329a99816ba546f62e.

## 2. Navigate the package

| Path | Purpose |
|---|---|
| REVIEW.md | Findings, limitations and suggested manuscript changes |
| ARTICLE_INSERTIONS.md | English paragraphs to merge into the supplied article |
| VISUAL_PLAN.md | Four publication figures, precise data and insertion locations |
| original/ | Original 50-file research package, including its own 49-entry manifest |
| fresh-capture/ | Second capture, original verifier scripts and unchanged observed anchor |
| review/ | Source checks, comparison data, byte vectors, execution logs and supplemental scripts |
| MANIFEST_SHA256.json | SHA-256 of every distributed file except this manifest |
| verify_review_package.py | Standard-library integrity check for this complete distribution |

The original uploaded ZIP identity is recorded in review/upload-source-identity.json. Original source notices and licensing files remain included.

## 3. Prepare Python

The recorded run used Linux and Python 3.12. The locked dependencies installed successfully in that environment. Native Windows and macOS execution have not been tested by this review. A platform without a compatible pyblst wheel may require its own build toolchain; that is an installation constraint, not a failed checkpoint.

For this publication bundle, open a terminal in DAVID_Week4_Publication and then change into evidence/. The complete guide and preserving ten-step launcher are in the publication root README.md and verify_all.py. The following commands are manual checks from this evidence directory. Check your Python version:

```bash
python --version
```

On Linux, create and use a dedicated environment without activating it:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r original/requirements-lock.txt
```

On Windows, the equivalent direct-interpreter commands are:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r original/requirements-lock.txt
```

The commands below use `python` as shorthand for that environment's interpreter. Substitute `.venv/bin/python` or `.venv\Scripts\python.exe` where appropriate. Using the interpreter directly does not require running an activation script or changing PowerShell execution policy.

Dependency installation needs network access. The saved-data checks below do not.

## 4. Verify distribution integrity first

Run these before any program that regenerates result files:

```bash
python verify_review_package.py
python original/verify_package.py
```

Expected: no mismatches. The original check also reports nine matching source Git-blob identities. A hash mismatch means the distributed bytes changed or a file is missing. Do not interpret it as a cryptographic checkpoint failure. A SHA-256 manifest proves consistency with the included manifest, not authenticity of the RPC observations or publisher.

## 5. Reproduce the original study

```bash
python original/verify_checkpoints.py
python original/verify_headers.py
```

Inspect original/results/summary.json, checkpoints.csv and header-checks.json. Expected coverage:

- 175 record digests and aggregate BLS signatures.
- 174 parent links and 174 committee handoff checks; one actual membership change.
- Three original py_ecc cross-checks, for epochs 0, 173 and 174.
- Thirteen local controls with their expected outcomes: twelve rejection controls and one deliberately valid synthetic positive control.
- Three RLP/Keccak execution-header commitment checks, including local gasUsed mutations.

The synthetic controls only exercise the separate offline verifier. Nothing malformed is submitted to Rayls. pyblst shares the blst cryptographic implementation with Axyl; py_ecc supplies the second-library check. The Python harness and serializer are not a compiled Axyl node.

## 6. Verify the second capture and compare it

```bash
python fresh-capture/verify_checkpoints.py
python fresh-capture/verify_headers.py
python review/compare_captures.py
```

Expected: two valid saved chains under the same observed anchor; 175 unchanged record objects/digests, 163 unchanged certificate objects, 12 alternative certificate objects and three identical block responses. The comparison program binds request IDs/methods to their returned epoch or block and compares both captures. It reuses the original verifier and is not a third cryptographic implementation.

Changed certificate epochs: 136, 138, 141, 147, 151, 152, 159, 161, 163, 164, 168 and 173. Exact signer indices and signature bytes are in review/recapture-comparison.json. The original epoch-173 six-signer observation is correct for the first capture; the later certificate has seven signers. Both satisfy six-of-eight.

## 7. Check all alternative certificates with the second library

```bash
python review/check_alternate_certificates.py
```

Expected: 24 PASS lines/checks, covering both certificate variants for each of 12 unchanged record commitments. These are not 24 new checkpoints. The recorded additional run used py_ecc 8.0.0; elapsed time depends on the machine. The program uses the original exact-byte reconstruction and py_ecc verification routine, and verifies expected committee membership before each cross-check.

## 8. Recalculate the encoding comparisons

```bash
python review/check_recipes.py
```

Expected matches against the 175 original records:

| Epoch width and hash | Matches |
|---|---:|
| u32 BCS + BLAKE3 | 175 |
| u32 BCS + Keccak | 0 |
| u64 BCS + BLAKE3 | 0 |
| u64 BCS + Keccak | 0 |

These additional offline recipe comparisons are separate from the original thirteen controls. The signed intent is 36 bytes: 01 00 01 for scope/version/application, 20 as the BCS length for a 32-byte vector, then the 32-byte record digest. Full record BCS and intent vectors for epochs 0, 173 and 174 are in review/review-byte-vectors.json.

## 9. Optional: fetch the fixed range again

Use a directory that does not already exist:

```bash
python original/fetch_again.py --output my-new-capture
```

The script checks chain ID 72957 and saves endpoint metadata, epochs 0 through 174 and the three sampled execution blocks. It uses HTTPS read-only JSON-RPC methods; it contains no wallet, signing or transaction-submission operation. Endpoint availability may change.

A new directory contains raw observations, not an automatically trusted anchor or completed verification. Preserve both old captures. Do not overwrite OBSERVED_ANCHOR.json with newly returned values or silently treat a different anchor as continuity. Reuse the reviewed verifier and original anchor only after inspecting the new capture. An unavailable RPC response is not a zero value or proof of a missing record.

## 10. Interpret results and publish responsibly

The strongest new distinction is that a record commitment can remain unchanged while its valid aggregate certificate has another authorized signer set. This review did not establish the operational cause of those alternatives. It found no changed record commitment in this fixed recapture range.

Read ARTICLE_INSERTIONS.md to update the manuscript, and VISUAL_PLAN.md for four publication evidence graphics. Their captions must keep the observed-anchor boundary visible. Final graphics should use the supplied Rayls mark unchanged, with its original black background; this supplement does not include or fabricate that asset.

Before publishing the article, upload the evidence to a public location and add a real repository/release/ZIP permalink to its reproduction section. This review did not create or update a GitHub repository. The supplement is a review, not a guarantee of a moderator score or a production light client.

The two original verification programs rewrite their result files. Subsequent generated files may no longer match a distribution manifest even when calculations still pass; re-extract a clean copy for a distribution-integrity check. Keep your own outputs outside the original capture when preserving its file identity matters.
