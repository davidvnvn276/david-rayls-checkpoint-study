"""Recalculate encoding/hash recipe comparisons and exact signed-byte samples."""
import json
import sys

sys.dont_write_bytecode = True
from review_common import ROOT, inputs


def main():
    verifier, original, _fresh, _anchor = inputs()
    counts = {k: 0 for k in ("u32_blake3", "u32_keccak", "u64_blake3", "u64_keccak")}
    vectors = {}
    for epoch, (record, certificate) in sorted(original.items()):
        u32 = verifier.encode_record(record)
        u64 = epoch.to_bytes(8, "little") + u32[4:]
        expected = verifier.hex32(certificate["epoch_hash"])
        for label, encoded in (("u32", u32), ("u64", u64)):
            counts[label + "_blake3"] += verifier.blake3.blake3(encoded).digest() == expected
            counts[label + "_keccak"] += verifier.keccak.new(digest_bits=256, data=encoded).digest() == expected
        if epoch in (0, 173, 174):
            intent = verifier.intent_message(expected)
            assert len(intent) == 36 and intent[:4] == bytes.fromhex("01000120")
            vectors[epoch] = {"bcs_record_length": len(u32), "intent_length": len(intent),
                              "intent_hex": intent.hex(), "record_hash": certificate["epoch_hash"]}
    saved = json.loads((ROOT / "review/review-recipe-checks.json").read_text())
    assert counts == saved["matches"] == {
        "u32_blake3": 175, "u32_keccak": 0, "u64_blake3": 0, "u64_keccak": 0}
    print(json.dumps({"status": "passed", "matches": counts, "vectors": vectors,
                      "scope": "Offline recipe sensitivity; not additional mainnet transactions."}, indent=2))


if __name__ == "__main__":
    main()
