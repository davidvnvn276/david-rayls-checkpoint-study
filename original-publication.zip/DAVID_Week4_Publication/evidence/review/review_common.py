"""Shared offline readers for the supplemental checkpoint checks."""
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]


def load_verifier():
    spec = importlib.util.spec_from_file_location(
        "checkpoint_research_verifier", ROOT / "original/verify_checkpoints.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_pairs(directory):
    """Bind complete response batches to their actual requested epochs."""
    pairs = {}
    for path in sorted((directory / "epochs").glob("batch-*.json")):
        payload = json.loads(path.read_text())
        requests, responses = payload["request"], payload["response"]
        assert isinstance(requests, list) and isinstance(responses, list), path
        ids = [request["id"] for request in requests]
        response_ids = [response["id"] for response in responses]
        assert len(ids) == len(set(ids)), f"Duplicate request ID: {path}"
        assert len(response_ids) == len(set(response_ids)), f"Duplicate response ID: {path}"
        assert set(ids) == set(response_ids), f"Incomplete batch: {path}"
        by_id = {request["id"]: request for request in requests}
        for response in responses:
            request = by_id[response["id"]]
            assert request["method"] == "rayls_epochRecord", path
            assert "error" not in response and "result" in response, path
            record, certificate = response["result"]
            epoch = record["epoch"]
            assert request["params"] == [epoch], f"Wrong request binding: {path}"
            assert epoch not in pairs, f"Duplicate epoch: {epoch}"
            pairs[epoch] = record, certificate
    assert sorted(pairs) == list(range(175)), "Expected exactly epochs 0 through 174"
    return pairs


def read_headers(directory):
    payload = json.loads((directory / "checkpoint-blocks.json").read_text())
    requests = {r["id"]: r for r in payload["request"]}
    responses = payload["response"]
    assert len(requests) == len(payload["request"]) == len(responses) == 3
    assert set(requests) == {r["id"] for r in responses}
    out = {}
    for response in responses:
        request = requests[response["id"]]
        assert request["method"] == "eth_getBlockByNumber"
        assert request["params"][1] is False
        assert "error" not in response and response.get("result") is not None
        block = response["result"]
        assert int(block["number"], 16) == int(request["params"][0], 16)
        out[int(block["number"], 16)] = block
    assert sorted(out) == [1, 12884728, 12948967]
    return out


def inputs():
    verifier = load_verifier()
    original = read_pairs(ROOT / "original")
    fresh = read_pairs(ROOT / "fresh-capture")
    anchor = json.loads((ROOT / "original/OBSERVED_ANCHOR.json").read_text())
    assert anchor == json.loads((ROOT / "fresh-capture/OBSERVED_ANCHOR.json").read_text())
    return verifier, original, fresh, anchor
