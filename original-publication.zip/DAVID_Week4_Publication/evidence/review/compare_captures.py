"""Compare both saved captures, including their signatures, using the original anchor.

No network requests. Reuses the packaged research verifier; this is not a new
cryptographic implementation. The independent-library check is a separate step.
"""
import json
import sys

sys.dont_write_bytecode = True
from review_common import ROOT, inputs, read_headers


def main():
    verifier, original, fresh, anchor = inputs()
    original_rows = verifier.verify_chain(original, anchor)
    fresh_rows = verifier.verify_chain(fresh, anchor)
    assert len(original_rows) == len(fresh_rows) == 175
    changes = []
    for epoch in sorted(original):
        old_record, old_cert = original[epoch]
        new_record, new_cert = fresh[epoch]
        assert old_record == new_record, f"Changed record at epoch {epoch}"
        assert old_cert["epoch_hash"] == new_cert["epoch_hash"]
        if old_cert != new_cert:
            others = set(old_cert) | set(new_cert)
            others -= {"signature", "signed_authorities"}
            assert all(old_cert[k] == new_cert[k] for k in others)
            assert old_cert["signature"] != new_cert["signature"]
            assert old_cert["signed_authorities"] != new_cert["signed_authorities"]
            a, b = original_rows[epoch], fresh_rows[epoch]
            changes.append({
                "epoch": epoch, "record_hash": old_cert["epoch_hash"],
                "committee_size": a["committee_size"],
                "required_signers": a["required_signers"],
                "original_signers": a["signers"], "recaptured_signers": b["signers"],
            })
    saved = json.loads((ROOT / "review/recapture-comparison.json").read_text())
    assert [r["epoch"] for r in changes] == saved["changed_epochs"]
    for observed, recorded in zip(changes, saved["certificate_pairs"]):
        assert observed["record_hash"] == recorded["record_hash"]
        assert observed["original_signers"] == recorded["old_signers"]
        assert observed["recaptured_signers"] == recorded["new_signers"]
    assert read_headers(ROOT / "original") == read_headers(ROOT / "fresh-capture")
    print(json.dumps({
        "status": "passed", "unchanged_record_objects_and_hashes": 175,
        "valid_chains": 2, "unchanged_certificates": 175 - len(changes),
        "changed_certificates": len(changes), "identical_header_responses": 3,
        "certificate_pairs": changes,
        "limit": "Both captures use the same observed anchor from the same endpoint.",
    }, indent=2))


if __name__ == "__main__":
    main()
