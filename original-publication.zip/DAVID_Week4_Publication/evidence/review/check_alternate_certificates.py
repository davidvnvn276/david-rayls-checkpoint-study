"""Recheck both saved certificate variants for all changed epochs using py_ecc.

Uses the original verifier's exact byte reconstruction and its second-library
verification routine. Twelve record commitments, twenty-four certificates.
"""
import json
import sys

sys.dont_write_bytecode = True
from review_common import ROOT, inputs


def main():
    verifier, original, fresh, anchor = inputs()
    changes = [epoch for epoch in sorted(original) if original[epoch][1] != fresh[epoch][1]]
    saved = json.loads((ROOT / "review/recapture-comparison.json").read_text())
    assert changes == saved["changed_epochs"]
    checks = []
    for epoch in changes:
        assert original[epoch][0] == fresh[epoch][0]
        expected = (verifier.committee_bytes(original[epoch - 1][0], "next_committee")
                    if epoch else [bytes.fromhex(s) for s in anchor["committee_hex"]])
        for label, capture in (("original", original), ("recaptured", fresh)):
            record, certificate = capture[epoch]
            verifier.verify_record(record, certificate, expected_committee=expected)
            assert verifier.py_ecc_crosscheck(record, certificate), (epoch, label)
            checks.append({"epoch": epoch, "capture": label, "py_ecc_valid": True})
            print(f"PASS: epoch {epoch}, {label} certificate", flush=True)
    assert len(checks) == 24
    print(json.dumps({"status": "passed", "record_commitments": len(changes),
                      "certificate_checks": len(checks), "implementation": "py_ecc 8.0.0",
                      "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
