# Review of the Week 4 checkpoint study

## Finding

The supplied results were reproduced. The principal numerical claims in the manuscript match the preserved observations. The source discrepancy is supported by the pinned release: the RPC prose describes Keccak and a u64 epoch field, while the implementation uses BLAKE3 and Epoch = u32.

A new read-only recapture supplies a further empirical finding. All 175 EpochRecord objects and their digests remained identical, but 12 certificates returned different signer bitmaps and aggregate signatures. Both versions of each certificate verified. The 24 certificate variants across those 12 record commitments were additionally checked with py_ecc.

This is useful information gain: certificate-byte identity and signed-record identity are different. The recapture does not establish why the endpoint returned different valid certificate variants. It does not independently authenticate the original committee or establish conflicting checkpoint commitments.

## Completed review

| Item | Result |
|---|---|
| Original archive | CRC passed; 50 entries, 49 manifest-covered files |
| Original integrity program | No mismatch; nine upstream source blob identities matched |
| Fresh GitHub source comparison | All nine packaged source files matched their blobs at the pinned commit |
| Release reference | Annotated mainnet-v1.4.1 tag resolved to commit 6909618ba3d178884e613b329a99816ba546f62e |
| Original offline certificate verifier | 175 record hashes/signatures passed; 174 parent links and 174 committee handoff checks passed |
| Original second-library checks | Epochs 0, 173 and 174 passed using py_ecc |
| Original local controls | All 13 passed their expected outcomes: 12 rejection controls and one valid synthetic positive control |
| Original execution headers | Three reconstructed Keccak/RLP header hashes matched their record commitments and RPC hashes |
| Fresh same-endpoint capture | Fixed range 0–174 retrieved; same observed anchor retained |
| Record comparison | 175 objects/digests identical |
| Certificate comparison | 163 identical, 12 different variants; all remain valid under the same respective committees |
| Additional second-library checks | 24 py_ecc checks passed, covering both variants for every changed epoch |
| Header recapture | The three returned block response objects matched the original capture |
| Encoding sensitivity | u32 BCS + BLAKE3: 175 matches. u32 + Keccak, u64 + BLAKE3, u64 + Keccak: zero matches each |

These counts describe coverage and repeatability, not independent live transactions or 24 new checkpoints. Both captures came from the same official RPC. The advertised node version is not binary attestation.

## Certificate variants

The changed epochs are 136, 138, 141, 147, 151, 152, 159, 161, 163, 164, 168 and 173. See recapture-comparison.json for exact signer indices and signature bytes.

At epoch 136 the original certificate names seven signers; the recapture names five. Both satisfy that seven-key committee's five-signer threshold and authenticate the same record digest. At epoch 173 the original capture has six of eight signers; the recapture has seven of eight. Both meet the six-signer threshold.

Keep the original article's six-signer observation tied to its 22 October capture. Do not silently replace it with the recapture's seven-signer count or describe the original result as wrong. The signer-count histogram differs between captures; record commitments and committee continuity do not.

## Manuscript changes before publication

1. Add the recapture finding and its exact capture dates. State that 12 alternative certificates were observed for unchanged records, and describe the validation rather than speculating about routing, aggregation timing or operational causes.
2. Describe the actual signed intent. In the inspected release the BCS-encoded signing input is 36 bytes: the three intent-domain bytes 01 00 01, a byte-vector length prefix 20, and the 32-byte record digest. It is not the bare digest by itself. Wrong-domain and missing-length controls already support this distinction.
3. Clarify that 174 committee handoff checks passed, while membership changed once, first appearing at epoch 172. Do not imply 174 distinct membership changes.
4. Add a direct pinned committee.rs link for the Epoch = u32 definition and an intent.rs link for the domain structure. Both files are already included in the evidence.
5. Add an actual public download/repository permalink for the author's evidence package. The current source list points to upstream material, not to a downloadable copy of this investigation.

The original article does not need to be reframed as a vulnerability report. Its limited claim—verification relative to an explicitly observed anchor—is appropriate. An authenticated out-of-band starting committee would support a stronger network-identity claim, but was not established by this review.

## Assessment for the content quest

The study has a credible basis for a high research score: real mainnet certificate observations, an implementation/documentation mismatch that affects reproductions, a visible committee change, negative controls, execution-header commitments, and a second cryptographic implementation.

The recapture adds an empirical distinction that is directly useful to a reader building a verifier. The number 175 alone is less informative than explaining the exact signed bytes, expected committee and treatment of valid certificate variants.

A 9 RP assessment remains the moderator's decision. The remaining observed-anchor dependency is a material scope limitation, not an automatically demonstrated protocol defect or an automatic score ceiling. Keep those boundaries visible in the article and figures.

## Source references

- https://docs.rayls.com/docs/public-chain-reference
- https://docs.rayls.com/docs/about-the-axyl-consensus-algorithm
- https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/primary/epoch.rs
- https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/committee.rs
- https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/mod.rs
- https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/intent.rs
- https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/doc/crates/execution/rpc.md
