# Proposed manuscript additions

These insertions are based on the additional records in this review package. They should be merged into the article with its original evidence boundaries and public evidence URL. The original supplied ZIP remains under original/.

## Add after reconstructing the exact signed record

The certificate's signing input also includes an intent domain. In this release, the verifier reconstructs a 36-byte BCS-encoded intent message: three bytes identifying scope, version and application, followed by the encoded 32-byte record digest. Changing the application domain or removing the digest's byte-vector length prefix causes signature verification to fail. Reproducing the record digest and reproducing the signed message are therefore separate steps.

## Add a section after following committee authority

### A repeat capture changed some certificates, not the records

I retrieved the same fixed epoch range again on 23 October 2026, retaining the original observed starting anchor. All 175 epoch records and their digests matched the 22 October capture. Twelve certificates, however, carried different signer bitmaps and aggregate signatures.

Both certificate variants passed verification against the unchanged record and its expected committee. I also checked both variants for each of those 12 epochs using py_ecc: all 24 additional checks passed.

At epoch 136, for example, the original certificate named seven signers and the later capture named five. Both met the seven-key committee's five-signer threshold. At epoch 173, the observed count changed from six to seven, with both meeting the eight-key committee's six-signer requirement.

The useful distinction is between the record being authenticated and the certificate supplying that authentication. Comparing certificate bytes alone would report differences even though the signed checkpoint commitment was unchanged. This repeat query does not establish why the endpoint returned different valid certificate variants, and using the same RPC again does not independently authenticate the starting committee.

## Clarify the continuity metric

Suggested wording: All 174 parent-hash links and all 174 next-committee handoff checks passed. The membership itself changed once, first appearing at epoch 172.

## Tie the signer observation to its capture

Suggested wording: In the 22 October capture, epoch 173 carried six signatures from its eight-key committee, meeting the six-signer threshold. The 23 October recapture returned a different valid seven-signer certificate for the same record.

## Add sources

- Epoch type: https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/committee.rs
- Intent domain: https://github.com/raylsnetwork/axyl/blob/6909618ba3d178884e613b329a99816ba546f62e/crates/infrastructure/types/src/crypto/intent.rs

The author's public evidence permalink must be supplied after upload. No repository or release was created or updated by this review.
