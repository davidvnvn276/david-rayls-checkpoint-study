# Four-figure publication plan

This publication uses one 5:2 banner and three 16:9 internal figures. This four-image layout supersedes the earlier five-image proposal, while the underlying observations remain unchanged.

| Figure | Placement | Evidence |
|---|---|---|
| 01-checkpoint-banner | Cover | 175 verified records; 174 parent links and handoffs; 12 valid certificate variants |
| 02-exact-signed-bytes | After Reconstructing the exact signed record | u32 BCS, BLAKE3, four-recipe comparison and exact 36-byte intent |
| 03-valid-certificate-variants | After A repeat capture changed certificates, not records | Epoch 136: 7 to 5 signers, threshold 5. Epoch 173: 6 to 7, threshold 6. Same respective record digests |
| 04-authority-and-header-commitments | After Connecting a signed record to an execution block | Observed starting committee; one 7-to-8-key change; three execution-header commitments |

The exact source logo is embedded without modification. No snapshot dates or account watermarks are placed inside the figures. The caption for figure 2 maps Capture A to 22 October 2026 and Capture B to 23 October 2026. Hash abbreviations are identified as such; full values remain in the data. The diagrams are SVG-based exact-data figures, not invented screenshots.
