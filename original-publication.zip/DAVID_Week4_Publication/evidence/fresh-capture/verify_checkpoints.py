"""Offline research verifier for captured Rayls epoch records; not a production light client.

Network access is intentionally absent. The observed epoch-0 anchor is an input,
not an independently authenticated statement of canonical network identity.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
from collections import Counter
from functools import lru_cache
from pathlib import Path

import base58
import blake3
import pyblst
from Crypto.Hash import keccak
from pyroaring import BitMap

ROOT = Path(__file__).resolve().parent
DST = b"BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_NUL_"
G2_BYTES = bytes.fromhex(
    "93e02b6052719f607dacd3a088274f65596bd0d09920b61ab5da61bbdc7f5049334cf11213945d57e5ac7d055d042b7e"
    "024aa2b2f08f0a91260805272dc51051c6e47ad4fa403b02b4510b647ae3d1770bac0326a805bbefd48056c8c121bdb8"
)
G2 = pyblst.BlstP2Element.uncompress(G2_BYTES)


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def uleb(n):
    require(isinstance(n, int) and 0 <= n <= 0xFFFFFFFF, "invalid BCS sequence length")
    out = bytearray()
    while n >= 128:
        out.append((n & 127) | 128)
        n >>= 7
    return bytes(out + bytes([n]))


def bcs_bytes(b):
    return uleb(len(b)) + b


def hex32(s):
    require(isinstance(s, str) and s.startswith("0x"), "expected prefixed hash")
    b = bytes.fromhex(s[2:])
    require(len(b) == 32, "expected 32-byte hash")
    return b


@lru_cache(maxsize=1024)
def public_key(raw):
    require(len(raw) == 96, "invalid public-key length")
    require(raw != bytes([0xC0]) + bytes(95), "infinity public key")
    return pyblst.BlstP2Element.uncompress(raw)


def committee_bytes(record, field="committee"):
    keys = sorted(base58.b58decode(x) for x in record[field])
    require(len(keys) > 0 and len(set(keys)) == len(keys), "empty or duplicate committee")
    for k in keys:
        public_key(k)
    return keys


def encode_record(record):
    # Epoch is u32, not the u64 listed in the release's RPC prose table.
    n = record["epoch"]
    require(isinstance(n, int) and 0 <= n < 2**32, "invalid epoch")
    out = n.to_bytes(4, "little")
    for field in ("committee", "next_committee"):
        keys = committee_bytes(record, field)
        out += uleb(len(keys)) + b"".join(bcs_bytes(k) for k in keys)
    out += bcs_bytes(hex32(record["parent_hash"]))
    block = record["parent_state"]["number"]
    require(isinstance(block, int) and 0 <= block < 2**64, "invalid block number")
    out += block.to_bytes(8, "little")
    out += bcs_bytes(hex32(record["parent_state"]["hash"]))
    out += bcs_bytes(hex32(record["parent_consensus"]))
    return out


def record_digest(record):
    return blake3.blake3(encode_record(record)).digest()


def intent_message(digest, app_id=1):
    return bytes([1, 0, app_id]) + bcs_bytes(digest)


def signature_valid(record, cert, *, message=None):
    keys = committee_bytes(record)
    ids = list(BitMap.deserialize(base58.b58decode(cert["signed_authorities"])))
    require(ids and all(0 <= i < len(keys) for i in ids), "invalid signer index")
    raw_sig = base58.b58decode(cert["signature"])
    require(len(raw_sig) == 48, "invalid signature length")
    require(raw_sig != bytes([0xC0]) + bytes(47), "infinity signature")
    sig = pyblst.BlstP1Element.uncompress(raw_sig)
    aggregate = public_key(keys[ids[0]])
    for i in ids[1:]:
        aggregate += public_key(keys[i])
    msg = message if message is not None else intent_message(hex32(cert["epoch_hash"]))
    hashed = pyblst.BlstP1Element.hash_to_group(msg, DST)
    return pyblst.final_verify(pyblst.miller_loop(sig, G2), pyblst.miller_loop(hashed, aggregate))


def verify_record(record, cert, *, expected_committee=None):
    digest = record_digest(record)
    require(digest == hex32(cert["epoch_hash"]), "record hash mismatch")
    keys = committee_bytes(record)
    if expected_committee is not None:
        require(keys == expected_committee, "unexpected committee")
    ids = list(BitMap.deserialize(base58.b58decode(cert["signed_authorities"])))
    require(all(i < len(keys) for i in ids), "invalid signer index")
    threshold = 2 * len(keys) // 3 + 1
    require(len(ids) >= threshold, "insufficient signer quorum")
    require(signature_valid(record, cert), "BLS verification failed")
    return {
        "epoch": record["epoch"], "committee_size": len(keys), "signers": len(ids),
        "required_signers": threshold, "checkpoint_block": record["parent_state"]["number"],
        "checkpoint_hash": record["parent_state"]["hash"], "record_hash": cert["epoch_hash"],
        "keccak_matches": keccak.new(digest_bits=256, data=encode_record(record)).digest() == digest,
    }


def read_pairs():
    pairs = {}
    for path in sorted((ROOT / "epochs").glob("batch-*.json")):
        payload = json.loads(path.read_text())
        requests = {r["id"]: r for r in payload["request"]}
        for response in payload["response"]:
            require("result" in response, f"RPC error in {path.name}: {response}")
            rec, cert = response["result"]
            require(requests[response["id"]]["params"] == [rec["epoch"]], "RPC request/epoch mismatch")
            require(rec["epoch"] not in pairs, "duplicate epoch capture")
            pairs[rec["epoch"]] = (rec, cert)
    return pairs


def verify_chain(pairs, anchor):
    expected_epochs = list(range(anchor["first_epoch"], anchor["last_epoch"] + 1))
    require(sorted(pairs) == expected_epochs, "missing or unexpected epoch")
    previous_record = previous_cert = None
    rows = []
    for epoch in expected_epochs:
        record, cert = pairs[epoch]
        if previous_record is None:
            require(cert["epoch_hash"] == anchor["record_hash"], "anchor mismatch")
            expected = [bytes.fromhex(s) for s in anchor["committee_hex"]]
        else:
            require(record["parent_hash"] == previous_cert["epoch_hash"], "parent link mismatch")
            require(record["parent_state"]["number"] > previous_record["parent_state"]["number"], "non-increasing checkpoint block")
            expected = committee_bytes(previous_record, "next_committee")
        rows.append(verify_record(record, cert, expected_committee=expected))
        previous_record, previous_cert = record, cert
    return rows


def py_ecc_crosscheck(record, cert):
    from py_ecc.bls.hash_to_curve import hash_to_G1
    from py_ecc.bls.point_compression import decompress_G1, decompress_G2
    from py_ecc.optimized_bls12_381 import G2 as generator, add, curve_order, is_inf, multiply, pairing
    ids = list(BitMap.deserialize(base58.b58decode(cert["signed_authorities"])))
    keys = committee_bytes(record)
    aggregate = None
    for i in ids:
        b = keys[i]
        p = decompress_G2((int.from_bytes(b[:48], "big"), int.from_bytes(b[48:], "big")))
        require(not is_inf(p) and is_inf(multiply(p, curve_order)), "py_ecc public-key group check")
        aggregate = p if aggregate is None else add(aggregate, p)
    sig = decompress_G1(int.from_bytes(base58.b58decode(cert["signature"]), "big"))
    require(not is_inf(sig) and is_inf(multiply(sig, curve_order)), "py_ecc signature group check")
    msg = intent_message(hex32(cert["epoch_hash"]))
    return pairing(generator, sig) == pairing(aggregate, hash_to_G1(msg, DST, hashlib.sha256))


def negative_tests(pairs, anchor):
    # All corruptions are applied to local copies. No malformed request is sent to any node.
    original_record, original_cert = pairs[174]
    tests = []

    def rejected(name, record, cert, expected=None):
        try:
            verify_record(record, cert, expected_committee=expected)
        except (ValueError, TypeError, OverflowError) as exc:
            tests.append({"test": name, "passed": True, "observed": str(exc)})
        else:
            raise AssertionError(f"negative control accepted: {name}")

    r, c = copy.deepcopy((original_record, original_cert))
    r["parent_state"]["hash"] = "0x" + "00" * 32
    rejected("alter checkpoint hash without rehashing", r, c)
    c["epoch_hash"] = "0x" + record_digest(r).hex()
    rejected("alter checkpoint hash and recompute digest, retaining old signature", r, c)

    r, c = copy.deepcopy((original_record, original_cert))
    c["signature"] = pairs[173][1]["signature"]
    rejected("splice signature from another epoch", r, c)

    r, c = copy.deepcopy((original_record, original_cert))
    ids = list(BitMap.deserialize(base58.b58decode(c["signed_authorities"])))
    c["signed_authorities"] = base58.b58encode(BitMap(ids[:-1]).serialize()).decode()
    rejected("remove one signer while retaining aggregate signature and enough claimed quorum", r, c)
    c["signed_authorities"] = base58.b58encode(BitMap(ids[:5]).serialize()).decode()
    rejected("below six-of-eight signer quorum", r, c)
    c["signed_authorities"] = base58.b58encode(BitMap(ids + [len(r["committee"])]).serialize()).decode()
    rejected("out-of-range signer bitmap", r, c)

    for name, msg in [
        ("wrong signature app domain", intent_message(hex32(original_cert["epoch_hash"]), 0)),
        ("omit BCS hash-length prefix in signed message", bytes([1, 0, 1]) + hex32(original_cert["epoch_hash"])),
    ]:
        require(not signature_valid(original_record, original_cert, message=msg), name)
        tests.append({"test": name, "passed": True, "observed": "BLS verification failed"})

    r, c = copy.deepcopy((original_record, original_cert))
    c["signature"] = base58.b58encode(bytes([0xC0]) + bytes(47)).decode()
    rejected("point-at-infinity signature", r, c)

    # A valid self-signed replacement committee is not an authorized mainnet committee.
    r = copy.deepcopy(original_record)
    secret = 123456789  # Public synthetic test scalar, never a live validator key.
    fake_key = G2.scalar_mul(secret).compress()
    r["committee"] = r["next_committee"] = [base58.b58encode(fake_key).decode()]
    digest = record_digest(r)
    sig = pyblst.BlstP1Element.hash_to_group(intent_message(digest), DST).scalar_mul(secret)
    c = {"epoch_hash": "0x" + digest.hex(), "signature": base58.b58encode(sig.compress()).decode(),
         "signed_authorities": base58.b58encode(BitMap([0]).serialize()).decode()}
    verify_record(r, c)
    tests.append({"test": "synthetic replacement committee passes self-signature mathematics", "passed": True,
                  "observed": "valid synthetic certificate, not an authentic Rayls certificate"})
    rejected("same self-signed replacement fails prior authenticated committee check", r, c,
             committee_bytes(pairs[173][0], "next_committee"))

    for name, changed_pairs, changed_anchor in [
        ("delete one epoch from chain", {e: p for e, p in pairs.items() if e != 90}, anchor),
        ("change observed anchor hash", pairs, dict(anchor, record_hash="0x" + "00" * 32)),
    ]:
        try:
            verify_chain(changed_pairs, changed_anchor)
        except ValueError as exc:
            tests.append({"test": name, "passed": True, "observed": str(exc)})
        else:
            raise AssertionError(name)
    return tests


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-second-library", action="store_true", help="Skip the three slower py_ecc cross-checks")
    args = parser.parse_args()
    pairs = read_pairs()
    anchor = json.loads((ROOT / "OBSERVED_ANCHOR.json").read_text())
    rows = verify_chain(pairs, anchor)
    checks = []
    if not args.skip_second_library:
        for epoch in [0, 173, 174]:
            passed = py_ecc_crosscheck(*pairs[epoch])
            require(passed, f"py_ecc verification failed at epoch {epoch}")
            checks.append({"epoch": epoch, "valid": passed})
    controls = negative_tests(pairs, anchor)
    changes = []
    for epoch in range(1, 175):
        before = committee_bytes(pairs[epoch - 1][0])
        after = committee_bytes(pairs[epoch][0])
        if before != after:
            changes.append({"first_epoch_with_new_committee": epoch, "before": len(before), "after": len(after),
                            "added_keys": len(set(after) - set(before)), "removed_keys": len(set(before) - set(after))})
    summary = {
        "scope": "Captured mainnet epoch certificates, independently processed offline; not full state replay or a production light client",
        "canonical_identity_limit": anchor["trust_limit"],
        "records_verified": len(rows), "first_epoch": rows[0]["epoch"], "last_epoch": rows[-1]["epoch"],
        "parent_links_verified": len(rows) - 1, "committee_transitions_checked": len(rows) - 1,
        "committee_size_counts": dict(Counter(r["committee_size"] for r in rows)),
        "signer_count_counts": dict(Counter(r["signers"] for r in rows)),
        "committee_changes": changes, "blake3_hash_matches": len(rows),
        "keccak_hash_matches_for_same_BCS_bytes": sum(r["keccak_matches"] for r in rows),
        "second_library_checks": checks, "offline_boundary_controls": controls,
        "total_controls": len(controls),
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (ROOT / "results/checkpoints.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
