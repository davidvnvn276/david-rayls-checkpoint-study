"""Recompute three EVM block header hashes and bind them to captured epoch records.

This checks header commitments, not transaction receipts or execution correctness.
"""
import json
from pathlib import Path
from Crypto.Hash import keccak
from verify_checkpoints import read_pairs, require

ROOT = Path(__file__).resolve().parent


def rlp(value):
    if isinstance(value, list):
        raw = b"".join(rlp(x) for x in value)
        offset = 0xC0
    else:
        raw = value
        if len(raw) == 1 and raw[0] < 0x80:
            return raw
        offset = 0x80
    if len(raw) <= 55:
        return bytes([offset + len(raw)]) + raw
    size = len(raw).to_bytes((len(raw).bit_length() + 7) // 8, "big")
    return bytes([offset + 55 + len(size)]) + size + raw


def h(value):
    return bytes.fromhex(value.removeprefix("0x"))


def quantity(value):
    n = int(value, 16)
    return n.to_bytes((n.bit_length() + 7) // 8, "big")


def encode_header(block):
    # Standard Ethereum header field ordering through Prague (EIP-7685).
    fields = [
        h(block["parentHash"]), h(block["sha3Uncles"]), h(block["miner"]),
        h(block["stateRoot"]), h(block["transactionsRoot"]), h(block["receiptsRoot"]),
        h(block["logsBloom"]), quantity(block["difficulty"]), quantity(block["number"]),
        quantity(block["gasLimit"]), quantity(block["gasUsed"]), quantity(block["timestamp"]),
        h(block["extraData"]), h(block["mixHash"]), h(block["nonce"]),
    ]
    for name, convert in [
        ("baseFeePerGas", quantity), ("withdrawalsRoot", h), ("blobGasUsed", quantity),
        ("excessBlobGas", quantity), ("parentBeaconBlockRoot", h), ("requestsHash", h),
    ]:
        require(block.get(name) is not None, f"missing expected Prague header field: {name}")
        fields.append(convert(block[name]))
    return rlp(fields)


def main():
    captured = json.loads((ROOT / "checkpoint-blocks.json").read_text())
    pairs = read_pairs()
    signed = {r["parent_state"]["number"]: (r["epoch"], r["parent_state"]["hash"])
              for r, _ in pairs.values()}
    rows = []
    for response in captured["response"]:
        block = response["result"]
        number = int(block["number"], 16)
        epoch, expected = signed[number]
        encoded = encode_header(block)
        digest = "0x" + keccak.new(digest_bits=256, data=encoded).hexdigest()
        require(digest == block["hash"] == expected, "header/checkpoint commitment mismatch")
        changed = dict(block, gasUsed=hex(int(block["gasUsed"], 16) + 1))
        require("0x" + keccak.new(digest_bits=256, data=encode_header(changed)).hexdigest() != expected,
                "header corruption not detected")
        rows.append({"epoch": epoch, "block": number, "signed_hash": expected,
                     "computed_header_hash": digest, "rlp_bytes": len(encoded),
                     "local_gasUsed_mutation_detected": True})
    require(sorted(r["epoch"] for r in rows) == [0, 173, 174], "unexpected header sample")
    result = {"scope": "Three captured checkpoint headers; no full execution replay or transaction inclusion proof",
              "headers_checked": rows}
    (ROOT / "results/header-checks.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
