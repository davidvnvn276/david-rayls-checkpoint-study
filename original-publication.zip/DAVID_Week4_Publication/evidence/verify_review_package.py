"""Check the review distribution against its SHA-256 manifest; standard library only."""
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / "MANIFEST_SHA256.json").read_text())
    failures = []
    for relative, expected in manifest["files"].items():
        path = PurePosixPath(relative)
        if path.is_absolute() or ".." in path.parts:
            failures.append("unsafe manifest path: " + relative)
            continue
        full = ROOT / relative
        if not full.is_file() or hashlib.sha256(full.read_bytes()).hexdigest() != expected:
            failures.append(relative)
    print(json.dumps({"status": "passed" if not failures else "failed",
                      "manifest_files": len(manifest["files"]), "mismatches": failures,
                      "limit": "Packaged-file integrity, not RPC, publisher or canonical-chain authentication."}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
