"""Run the fixed saved-data audit offline, preserving packaged observations.

Creates a new output directory, verifies integrity first, and runs all programs
that regenerate results against a separate working copy of evidence/.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def main():
    if not __debug__:
        raise SystemExit("Run without -O or -OO: supplemental verification uses assertions.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", help="New output directory; must not already exist.")
    args = parser.parse_args()
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = Path(args.output).expanduser().resolve() if args.output else ROOT / "audit-output" / stamp
    if output == ROOT or output.is_relative_to(ROOT / "evidence"):
        raise SystemExit("Output must be separate from the packaged evidence directory.")
    output.mkdir(parents=True, exist_ok=False)
    logs = output / "logs"
    logs.mkdir()
    working = output / "working-evidence"
    manifest_before = hashlib.sha256((ROOT / "MANIFEST_SHA256.json").read_bytes()).hexdigest()
    steps = []
    start = time.monotonic()

    def run(label, program):
        number = len(steps) + 1
        log = logs / f"{number:02d}-{label}.log"
        command = [sys.executable, "-B", str(program)]
        print(f"[{number:02d}/10] {label}", flush=True)
        began = time.monotonic()
        with log.open("w", encoding="utf-8") as f:
            process = subprocess.run(command, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, check=False)
        item = {"step": number, "name": label, "command": command,
                "exit_code": process.returncode, "log": str(log.relative_to(output)),
                "seconds": round(time.monotonic() - began, 3)}
        steps.append(item)
        print(("PASS" if process.returncode == 0 else "FAIL") + f": {label}", flush=True)
        if process.returncode:
            raise RuntimeError(f"{label} failed; inspect {log}")

    error = None
    try:
        run("publication-integrity", ROOT / "verify_publication.py")
        run("review-integrity", ROOT / "evidence/verify_review_package.py")
        run("original-integrity", ROOT / "evidence/original/verify_package.py")
        shutil.copytree(ROOT / "evidence", working, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        for label, relative in [
            ("original-checkpoints", "original/verify_checkpoints.py"),
            ("original-headers", "original/verify_headers.py"),
            ("recaptured-checkpoints", "fresh-capture/verify_checkpoints.py"),
            ("recaptured-headers", "fresh-capture/verify_headers.py"),
            ("capture-comparison", "review/compare_captures.py"),
            ("alternate-certificates-pyecc", "review/check_alternate_certificates.py"),
            ("encoding-recipes", "review/check_recipes.py"),
        ]:
            run(label, working / relative)
        from verify_publication import verify
        final_integrity = verify()
        if final_integrity["status"] != "passed":
            raise RuntimeError("Packaged files changed during the audit: " + json.dumps(final_integrity["mismatches"]))
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    manifest_after = hashlib.sha256((ROOT / "MANIFEST_SHA256.json").read_bytes()).hexdigest()
    result = {"status": "failed" if error else "passed",
              "started_at_utc": stamp, "python": sys.version,
              "steps_completed": len(steps), "expected_steps": 10,
              "manifest_identity_preserved": manifest_before == manifest_after,
              "seconds": round(time.monotonic() - start, 3), "steps": steps,
              "error": error,
              "scope": "Fixed saved captures only; no live RPC, wallets or transactions.",
              "trust_limit": "The original observed starting committee remains unauthenticated out of band."}
    (output / "audit-summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ["status", "steps_completed", "expected_steps", "seconds", "error"]}, indent=2))
    print(f"Report: {output / 'audit-summary.json'}")
    if error:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
